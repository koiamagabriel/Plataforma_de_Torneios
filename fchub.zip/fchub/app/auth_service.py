from app.storage import get_next_user_id, load_users, save_users


class AuthService:
    def register_user(self, email: str, password: str) -> tuple[bool, str]:
        email = email.strip().lower()
        password = password.strip()

        if not email or not password:
            return False, "E-mail e senha são obrigatórios."

        if not self._is_valid_domain(email):
            return False, "O e-mail deve terminar com admin.com ou gmail.com."

        users = load_users()

        if any(user["email"] == email for user in users):
            return False, "Este e-mail já está cadastrado."

        role = self._get_role_by_email(email)

        new_user = {
            "id": get_next_user_id(),
            "email": email,
            "password": password,
            "role": role,
        }

        users.append(new_user)
        save_users(users)

        return True, "Usuário cadastrado com sucesso."

    def login_user(self, email: str, password: str) -> tuple[bool, str, dict | None]:
        email = email.strip().lower()
        password = password.strip()

        if not email or not password:
            return False, "E-mail e senha são obrigatórios.", None

        users = load_users()

        for user in users:
            if user["email"] == email and user["password"] == password:
                return True, "Login realizado com sucesso.", user

        return False, "E-mail ou senha inválidos.", None

    def get_user_by_email(self, email: str) -> dict | None:
        email = email.strip().lower()
        users = load_users()

        for user in users:
            if user["email"] == email:
                return user

        return None

    def _is_valid_domain(self, email: str) -> bool:
        return email.endswith("@admin.com") or email.endswith("@gmail.com")

    def _get_role_by_email(self, email: str) -> str:
        if email.endswith("@admin.com"):
            return "admin"
        return "user"