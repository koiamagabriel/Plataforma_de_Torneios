from typing import Any

from app.storage import load_matches


class ValidacaoResultadoService:
    """
    Serviço responsável por validar se um resultado informado
    pode ser aceito para uma partida específica.
    """

    def validar_resultado_partida(
        self,
        id_partida: int,
        current_user: dict | None,
        placar_jogador_a: Any,
        placar_jogador_b: Any,
    ) -> tuple[bool, str, dict | None]:
        """
        Valida:
        - se o usuário está autenticado;
        - se a partida existe;
        - se o usuário participa da partida;
        - se a partida aceita registro de resultado;
        - se ainda não existe resultado pendente;
        - se os placares são números inteiros válidos;
        - se não houve empate.

        Retorna:
        (sucesso, mensagem, dados_validados)
        """

        if not current_user:
            return False, "Usuário não autenticado.", None

        matches = load_matches()
        match = self._find_match(matches, id_partida)

        if not match:
            return False, "Partida não encontrada.", None

        if not self._is_user_in_match(match, current_user["id"]):
            return False, "Você não participa desta partida.", None

        if match.get("status") != "pendente":
            return False, "Esta partida não está disponível para registro de resultado.", None

        if match.get("status_resultado") != "nao_informado":
            return False, "Já existe um resultado registrado para esta partida.", None

        placar_a_ok, placar_a = self._parse_score(placar_jogador_a)
        if not placar_a_ok:
            return False, "O placar do Jogador A é inválido. Informe apenas números inteiros maiores ou iguais a zero.", None

        placar_b_ok, placar_b = self._parse_score(placar_jogador_b)
        if not placar_b_ok:
            return False, "O placar do Jogador B é inválido. Informe apenas números inteiros maiores ou iguais a zero.", None

        if placar_a == placar_b:
            return False, "Empate não é permitido. Informe um placar com vencedor definido.", None

        dados_validados = {
            "id_partida": id_partida,
            "placar_jogador_a": placar_a,
            "placar_jogador_b": placar_b,
            "status_validacao_resultado": "valido",
        }

        return True, "Resultado válido para registro.", dados_validados

    def _find_match(self, matches: list[dict], id_partida: int) -> dict | None:
        for match in matches:
            if match["id"] == id_partida:
                return match
        return None

    def _is_user_in_match(self, match: dict, user_id: int) -> bool:
        return user_id in (
            match.get("jogador_a_id"),
            match.get("jogador_b_id"),
        )

    def _parse_score(self, value: Any) -> tuple[bool, int | None]:
        """
        Converte o valor informado para inteiro e garante
        que seja um número inteiro maior ou igual a zero.
        Não aceita vazio, decimal, texto ou número negativo.
        """
        if value is None:
            return False, None

        text = str(value).strip()
        if text == "":
            return False, None

        # Não aceita decimal nem caracteres não numéricos
        if not text.isdigit():
            return False, None

        try:
            score = int(text)
        except (TypeError, ValueError):
            return False, None

        if score < 0:
            return False, None

        return True, score