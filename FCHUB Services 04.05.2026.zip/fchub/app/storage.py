import json
from pathlib import Path
from typing import Any


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"

USERS_FILE = DATA_DIR / "users.json"
TOURNAMENTS_FILE = DATA_DIR / "tournaments.json"
MATCHES_FILE = DATA_DIR / "matches.json"


def _ensure_data_dir() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def _read_json(file_path: Path, default: Any) -> Any:
    _ensure_data_dir()

    if not file_path.exists():
        _write_json(file_path, default)
        return default

    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except json.JSONDecodeError:
        _write_json(file_path, default)
        return default


def _write_json(file_path: Path, data: Any) -> None:
    _ensure_data_dir()
    with open(file_path, "w", encoding="utf-8") as file:
        json.dump(data, file, ensure_ascii=False, indent=2)


def _seed_users() -> list[dict[str, Any]]:
    """
    Usuários iniciais fixos do sistema.
    """
    return [
        {
            "id": 1,
            "email": "user@admin.com",
            "password": "123456",
            "role": "admin",
        },
        {
            "id": 2,
            "email": "user@gmail.com",
            "password": "123456",
            "role": "user",
        },
    ]


def _normalize_match(match: dict[str, Any]) -> dict[str, Any]:
    """
    Garante compatibilidade de partidas antigas com os novos
    campos necessários para registro e validação de resultado.
    """
    normalized_match = dict(match)

    if "placar_jogador_a" not in normalized_match:
        normalized_match["placar_jogador_a"] = None

    if "placar_jogador_b" not in normalized_match:
        normalized_match["placar_jogador_b"] = None

    if "resultado_registrado_por" not in normalized_match:
        normalized_match["resultado_registrado_por"] = None

    if "status_resultado" not in normalized_match:
        normalized_match["status_resultado"] = "nao_informado"

    return normalized_match


def initialize_storage() -> None:
    """
    Garante a criação dos arquivos base do sistema.
    """
    _ensure_data_dir()

    if not USERS_FILE.exists():
        _write_json(USERS_FILE, _seed_users())

    if not TOURNAMENTS_FILE.exists():
        _write_json(TOURNAMENTS_FILE, [])

    if not MATCHES_FILE.exists():
        _write_json(MATCHES_FILE, [])


# =========================
# USERS
# =========================

def load_users() -> list[dict[str, Any]]:
    return _read_json(USERS_FILE, _seed_users())


def save_users(users: list[dict[str, Any]]) -> None:
    _write_json(USERS_FILE, users)


def get_next_user_id() -> int:
    users = load_users()
    if not users:
        return 1
    return max(user["id"] for user in users) + 1


# =========================
# TOURNAMENTS
# =========================

def load_tournaments() -> list[dict[str, Any]]:
    return _read_json(TOURNAMENTS_FILE, [])


def save_tournaments(tournaments: list[dict[str, Any]]) -> None:
    _write_json(TOURNAMENTS_FILE, tournaments)


def get_next_tournament_id() -> int:
    tournaments = load_tournaments()
    if not tournaments:
        return 1
    return max(tournament["id"] for tournament in tournaments) + 1


# =========================
# MATCHES
# =========================

def load_matches() -> list[dict[str, Any]]:
    matches = _read_json(MATCHES_FILE, [])
    normalized_matches = [_normalize_match(match) for match in matches]

    # Se houve normalização, já salva de volta no arquivo
    if normalized_matches != matches:
        _write_json(MATCHES_FILE, normalized_matches)

    return normalized_matches


def save_matches(matches: list[dict[str, Any]]) -> None:
    normalized_matches = [_normalize_match(match) for match in matches]
    _write_json(MATCHES_FILE, normalized_matches)


def get_next_match_id() -> int:
    matches = load_matches()
    if not matches:
        return 1
    return max(match["id"] for match in matches) + 1