import os
import random
from typing import Any

from app.storage import (
    get_next_tournament_id,
    load_matches,
    load_tournaments,
    save_matches,
    save_tournaments,
)

try:
    import challonge
except ImportError:  # pragma: no cover
    challonge = None


class TorneiosService:
    def __init__(self) -> None:
        self.challonge_user = os.getenv("CHALLONGE_USER", "").strip()
        self.challonge_api_key = os.getenv("CHALLONGE_API_KEY", "").strip()
        self._challonge_configured = False

    # =========================
    # API pública
    # =========================

    def create_tournament(
        self,
        nome: str,
        formato: int,
        current_user: dict,
    ) -> tuple[bool, str, dict | None]:
        """
        Cria um torneio.
        Apenas admin pode criar.
        """
        if not current_user or current_user.get("role") != "admin":
            return False, "Apenas administradores podem criar torneios.", None

        nome = nome.strip()

        if not nome:
            return False, "O nome do torneio é obrigatório.", None

        if formato not in (8, 16):
            return False, "O formato do torneio deve ser 8 ou 16.", None

        tournaments = load_tournaments()

        new_tournament = {
            "id": get_next_tournament_id(),
            "nome": nome,
            "formato": formato,
            "status": "aberto",
            "max_jogadores": formato,
            "inscritos": [],
            "created_by": current_user["email"],
            "challonge_id": None,
            "challonge_url": None,
        }

        tournaments.append(new_tournament)
        save_tournaments(tournaments)

        return True, "Torneio criado com sucesso.", new_tournament

    def list_tournaments(self) -> list[dict]:
        tournaments = load_tournaments()
        return sorted(tournaments, key=lambda t: t["id"])

    def get_tournament_by_id(self, tournament_id: int) -> dict | None:
        tournaments = load_tournaments()
        for tournament in tournaments:
            if tournament["id"] == tournament_id:
                return tournament
        return None

    def subscribe_user(
        self,
        tournament_id: int,
        current_user: dict,
    ) -> tuple[bool, str]:
        """
        Inscreve usuário em um torneio.
        Quando atingir a lotação, gera as partidas automaticamente.
        """
        if not current_user:
            return False, "Usuário não autenticado."

        tournaments = load_tournaments()
        tournament = self._find_tournament(tournaments, tournament_id)

        if not tournament:
            return False, "Torneio não encontrado."

        if tournament["status"] != "aberto":
            return False, "Este torneio não está aberto para inscrições."

        already_registered = any(
            participant["user_id"] == current_user["id"]
            for participant in tournament["inscritos"]
        )
        if already_registered:
            return False, "Você já está inscrito neste torneio."

        if len(tournament["inscritos"]) >= tournament["max_jogadores"]:
            return False, "Este torneio já atingiu o limite de jogadores."

        tournament["inscritos"].append(
            {
                "user_id": current_user["id"],
                "email": current_user["email"],
                "role": current_user["role"],
            }
        )

        # Se lotou, cria torneio no Challonge e gera partidas automaticamente
        if len(tournament["inscritos"]) == tournament["max_jogadores"]:
            tournament["status"] = "em_andamento"
            self._sync_with_challonge(tournament)
            self._generate_matches(
                tournament_id=tournament["id"],
                participants=tournament["inscritos"],
            )

        save_tournaments(tournaments)
        return True, "Inscrição realizada com sucesso."

    def get_matches_by_tournament(self, tournament_id: int) -> list[dict]:
        matches = load_matches()
        tournament_matches = [
            match for match in matches if match["tournament_id"] == tournament_id
        ]
        return sorted(tournament_matches, key=lambda m: (m["rodada"], m["id"]))

    # =========================
    # Helpers internos
    # =========================

    def _find_tournament(
        self,
        tournaments: list[dict],
        tournament_id: int,
    ) -> dict | None:
        for tournament in tournaments:
            if tournament["id"] == tournament_id:
                return tournament
        return None

    def _generate_matches(self, tournament_id: int, participants: list[dict]) -> None:
        """
        Gera as partidas iniciais do torneio quando ele atinge o número máximo
        de jogadores. Cada partida já nasce com os campos necessários para o
        fluxo de validação e registro de resultado.
        """
        if not participants:
            return

        if len(participants) % 2 != 0:
            return

        matches = load_matches()

        # Evita gerar partidas duplicadas para o mesmo torneio
        already_exists = any(match["tournament_id"] == tournament_id for match in matches)
        if already_exists:
            return

        shuffled_participants = participants[:]
        random.shuffle(shuffled_participants)

        next_match_id = max((match["id"] for match in matches), default=0) + 1

        for i in range(0, len(shuffled_participants), 2):
            jogador_a = shuffled_participants[i]
            jogador_b = shuffled_participants[i + 1]

            match = {
                "id": next_match_id,
                "tournament_id": tournament_id,
                "rodada": 1,
                "jogador_a_id": jogador_a["user_id"],
                "jogador_a_email": jogador_a["email"],
                "jogador_b_id": jogador_b["user_id"],
                "jogador_b_email": jogador_b["email"],
                "status": "pendente",
                "vencedor": None,
                "placar_jogador_a": None,
                "placar_jogador_b": None,
                "resultado_registrado_por": None,
                "status_resultado": "nao_informado",
            }

            matches.append(match)
            next_match_id += 1

        save_matches(matches)

    def _sync_with_challonge(self, tournament: dict) -> None:
        """
        Tenta criar e iniciar o torneio no Challonge.
        Se não houver credenciais ou biblioteca, segue normalmente.
        """
        if not self._is_challonge_available():
            return

        self._configure_challonge_once()

        try:
            slug = f"torneio-{tournament['id']}-{tournament['formato']}"

            created = challonge.tournaments.create(
                tournament["nome"],
                slug,
                tournament_type="single elimination",
            )

            challonge_id = self._extract_value(created, "id")
            challonge_url = self._extract_value(created, "full_challonge_url")
            if not challonge_url:
                challonge_url = self._extract_value(created, "url")

            tournament["challonge_id"] = str(challonge_id) if challonge_id else None
            tournament["challonge_url"] = challonge_url

            external_tournament_id = tournament["challonge_id"] or slug

            for participant in tournament["inscritos"]:
                challonge.participants.create(
                    external_tournament_id,
                    participant["email"],
                )

            challonge.tournaments.start(external_tournament_id)

        except Exception:
            # Se der qualquer erro no Challonge, o sistema continua funcionando localmente
            tournament["challonge_id"] = None
            tournament["challonge_url"] = None

    def _is_challonge_available(self) -> bool:
        return (
            challonge is not None
            and bool(self.challonge_user)
            and bool(self.challonge_api_key)
        )

    def _configure_challonge_once(self) -> None:
        if self._challonge_configured:
            return

        challonge.set_credentials(self.challonge_user, self.challonge_api_key)
        self._challonge_configured = True

    @staticmethod
    def _extract_value(data: Any, key: str) -> Any:
        if isinstance(data, dict):
            return data.get(key)
        return getattr(data, key, None)