from urllib.parse import quote_plus

from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

from app.auth_service import AuthService
from app.registrar_resultado_service import RegistrarResultadoService
from app.storage import initialize_storage
from app.torneios_service import TorneiosService
from app.validacao_resultado_service import ValidacaoResultadoService

app = FastAPI(title="FCHub")

app.add_middleware(SessionMiddleware, secret_key="fchub-secret-key")

app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/template")

auth_service = AuthService()
torneios_service = TorneiosService()
validacao_resultado_service = ValidacaoResultadoService()
registrar_resultado_service = RegistrarResultadoService()


# =========================
# Inicialização
# =========================

@app.on_event("startup")
def startup_event() -> None:
    initialize_storage()


# =========================
# Helpers
# =========================

def get_current_user(request: Request) -> dict | None:
    return request.session.get("user")


def is_admin(user: dict | None) -> bool:
    return bool(user and user.get("role") == "admin")


def redirect_with_message(url: str, message: str, error: bool = False) -> RedirectResponse:
    encoded_message = quote_plus(message)
    separator = "&" if "?" in url else "?"
    return RedirectResponse(
        url=f"{url}{separator}msg={encoded_message}&error={int(error)}",
        status_code=303,
    )


# =========================
# Rotas principais
# =========================

@app.get("/", response_class=HTMLResponse)
def root(request: Request):
    user = get_current_user(request)
    if user:
        return RedirectResponse(url="/menu", status_code=303)
    return RedirectResponse(url="/auth", status_code=303)


# =========================
# Autenticação
# =========================

@app.get("/auth", response_class=HTMLResponse)
def auth_page(request: Request):
    user = get_current_user(request)
    if user:
        return RedirectResponse(url="/menu", status_code=303)

    msg = request.query_params.get("msg", "")
    error = request.query_params.get("error", "0") == "1"

    return templates.TemplateResponse(
        "auth.html",
        {
            "request": request,
            "msg": msg,
            "error": error,
        },
    )


@app.post("/register")
def register(
    email: str = Form(...),
    password: str = Form(...),
):
    success, message = auth_service.register_user(email=email, password=password)

    if not success:
        return redirect_with_message("/auth", message, error=True)

    return redirect_with_message("/auth", "Cadastro realizado com sucesso. Faça login.")


@app.post("/login")
def login(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
):
    success, message, user = auth_service.login_user(email=email, password=password)

    if not success or not user:
        return redirect_with_message("/auth", message, error=True)

    request.session["user"] = user
    return redirect_with_message("/menu", "Login realizado com sucesso.")


@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    return redirect_with_message("/auth", "Logout realizado com sucesso.")


# =========================
# Menu principal
# =========================

@app.get("/menu", response_class=HTMLResponse)
def menu_page(request: Request):
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth", status_code=303)

    msg = request.query_params.get("msg", "")
    error = request.query_params.get("error", "0") == "1"

    return templates.TemplateResponse(
        "menu.html",
        {
            "request": request,
            "user": user,
            "msg": msg,
            "error": error,
            "is_admin": is_admin(user),
        },
    )


# =========================
# Torneios
# =========================

@app.get("/torneios", response_class=HTMLResponse)
def list_tournaments(request: Request):
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth", status_code=303)

    tournaments = torneios_service.list_tournaments()

    tournaments_view = []
    for tournament in tournaments:
        inscritos = tournament.get("inscritos", [])
        matches = torneios_service.get_matches_by_tournament(tournament["id"])

        tournaments_view.append(
            {
                "id": tournament["id"],
                "nome": tournament["nome"],
                "formato": tournament["formato"],
                "status": tournament["status"],
                "status_label": str(tournament["status"]).replace("_", " ").title(),
                "max_jogadores": tournament["max_jogadores"],
                "quantidade_inscritos": len(inscritos),
                "created_by": tournament["created_by"],
                "challonge_url": tournament.get("challonge_url"),
                "inscritos": inscritos,
                "matches": matches,
            }
        )

    msg = request.query_params.get("msg", "")
    error = request.query_params.get("error", "0") == "1"

    return templates.TemplateResponse(
        "torneios.html",
        {
            "request": request,
            "user": user,
            "tournaments": tournaments_view,
            "msg": msg,
            "error": error,
            "is_admin": is_admin(user),
        },
    )


@app.post("/torneios/{tournament_id}/inscrever")
def subscribe_in_tournament(request: Request, tournament_id: int):
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth", status_code=303)

    success, message = torneios_service.subscribe_user(
        tournament_id=tournament_id,
        current_user=user,
    )

    return redirect_with_message("/torneios", message, error=not success)


@app.post("/partidas/{match_id}/resultado")
def registrar_resultado_partida(
    request: Request,
    match_id: int,
    placar_jogador_a: str = Form(...),
    placar_jogador_b: str = Form(...),
):
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth", status_code=303)

    sucesso_validacao, mensagem_validacao, dados_validados = (
        validacao_resultado_service.validar_resultado_partida(
            id_partida=match_id,
            current_user=user,
            placar_jogador_a=placar_jogador_a,
            placar_jogador_b=placar_jogador_b,
        )
    )

    if not sucesso_validacao or not dados_validados:
        return redirect_with_message("/torneios", mensagem_validacao, error=True)

    sucesso_registro, mensagem_registro, _ = (
        registrar_resultado_service.registrar_resultado_pendente(
            id_partida=dados_validados["id_partida"],
            current_user=user,
            placar_jogador_a=dados_validados["placar_jogador_a"],
            placar_jogador_b=dados_validados["placar_jogador_b"],
        )
    )

    return redirect_with_message(
        "/torneios",
        mensagem_registro,
        error=not sucesso_registro,
    )


# =========================
# Criar torneio
# =========================

@app.get("/criar-torneio", response_class=HTMLResponse)
def create_tournament_page(request: Request):
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth", status_code=303)

    if not is_admin(user):
        return redirect_with_message("/menu", "Apenas administradores podem acessar essa página.", error=True)

    msg = request.query_params.get("msg", "")
    error = request.query_params.get("error", "0") == "1"

    return templates.TemplateResponse(
        "criar_torneio.html",
        {
            "request": request,
            "user": user,
            "msg": msg,
            "error": error,
        },
    )


@app.post("/criar-torneio")
def create_tournament(
    request: Request,
    nome: str = Form(...),
    formato: int = Form(...),
):
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/auth", status_code=303)

    if not is_admin(user):
        return redirect_with_message("/menu", "Apenas administradores podem criar torneios.", error=True)

    success, message, _ = torneios_service.create_tournament(
        nome=nome,
        formato=formato,
        current_user=user,
    )

    if not success:
        return redirect_with_message("/criar-torneio", message, error=True)

    return redirect_with_message("/torneios", message)