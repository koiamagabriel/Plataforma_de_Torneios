from app.storage import load_matches, save_matches


class RegistrarResultadoService:
    """
    Serviço responsável por registrar o resultado informado
    em uma partida específica e deixá-la como aguardando confirmação.
    """

    def registrar_resultado_pendente(
        self,
        id_partida: int,
        current_user: dict | None,
        placar_jogador_a: int,
        placar_jogador_b: int,
    ) -> tuple[bool, str, dict | None]:
        """
        Registra o resultado informado na partida, desde que:
        - o usuário esteja autenticado;
        - a partida exista;
        - o usuário participe da partida;
        - a partida ainda esteja pendente;
        - ainda não exista resultado informado.

        Retorna:
        (sucesso, mensagem, resposta_servico)
        """

        if not current_user:
            return False, "Usuário não autenticado.", None

        matches = load_matches()
        match = self._find_match(matches, id_partida)

        if not match:
            return False, "Partida não encontrada.", None

        if not self._is_user_in_match(match, current_user["id"]):
            return False, "Você não participa desta partida.", None

        if match.get("status") != "pendente":
            return False, "Esta partida não permite registro de resultado.", None

        if match.get("status_resultado") != "nao_informado":
            return False, "Esta partida já possui um resultado registrado.", None

        match["placar_jogador_a"] = placar_jogador_a
        match["placar_jogador_b"] = placar_jogador_b
        match["resultado_registrado_por"] = current_user["id"]
        match["status_resultado"] = "aguardando_confirmacao"

        save_matches(matches)

        resposta_servico = {
            "id_partida": id_partida,
            "status_partida": "aguardando_confirmacao",
        }

        return True, "Resultado registrado com sucesso e aguardando confirmação.", resposta_servico

    def _find_match(self, matches: list[dict], id_partida: int) -> dict | None:
        for match in matches:
            if match["id"] == id_partida:
                return match
        return None

    def _is_user_in_match(self, match: dict, user_id: int) -> bool:
        return user_id in (
            match.get("jogador_a_id"),
            match.get("jogador_b_id"),
        )